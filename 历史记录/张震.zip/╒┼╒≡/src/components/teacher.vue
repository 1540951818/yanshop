<template>
  <div>
        教师管理
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: [

  ],
  components:{
  },
  mounted() {

  },
  methods:{

  },
 }
</script>

<style scoped>
</style>